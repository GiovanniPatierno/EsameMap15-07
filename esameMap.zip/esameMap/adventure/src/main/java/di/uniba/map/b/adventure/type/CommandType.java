/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package di.uniba.map.b.adventure.type;

public enum CommandType {
    FINE, INVENTARIO, AVANTI, INDIETRO, SINISTRA, DESTRA, APRI, CHIUDI, PRENDI, GUARDA, MAPPA
}
