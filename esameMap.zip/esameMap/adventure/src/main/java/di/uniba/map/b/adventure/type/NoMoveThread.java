package di.uniba.map.b.adventure.type;

public class NoMoveThread extends Thread {
    long minPrime;
    public NoMoveThread(long minPrime){
        this.minPrime = minPrime;
    }

    public NoMoveThread() {
        
    }

    public void run(){
        System.out.println("no! non sei ancora un fantasma, purtoppo non puoi ancora attraversare  i muri");
    }
}
